package com.zuno.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

data class User(val id: String, val name: String, val status: String, val about: String, val initials: String)
data class Post(val id: String, val author: User, val text: String, val time: String, val likes: Int, val comments: Int, val hasPhoto: Boolean)
data class Chat(val id: String, val user: User, val lastMessage: String, val time: String, val unread: Int)

class ZunoViewModel : ViewModel() {
    val me = User("me", "Tom", "В сети", "Люблю технологии, игры и новые знакомства.", "T")
    val users = listOf(
        me,
        User("anna", "Анна", "В сети", "Фотография, путешествия и кофе.", "А"),
        User("max", "Макс", "Был недавно", "Музыка и спорт.", "М"),
        User("lisa", "Лиза", "В сети", "Создаю и вдохновляюсь.", "Л")
    )
    var posts by mutableStateOf(listOf(
        Post("1", users[1], "Сегодня отличный день! ☀️", "10 мин", 24, 5, true),
        Post("2", users[2], "Кто-нибудь идёт сегодня гулять?", "35 мин", 12, 2, false),
        Post("3", me, "Добро пожаловать в Zuno!", "1 ч", 31, 7, false)
    ))
        private set

    var chats by mutableStateOf(listOf(
        Chat("1", users[1], "Привет! Как дела?", "10:42", 2),
        Chat("2", users[2], "Увидимся вечером", "09:18", 0)
    ))
        private set

    fun addPost(text: String) {
        if (text.isNotBlank()) posts = listOf(Post(System.currentTimeMillis().toString(), me, text, "только что", 0, 0, false)) + posts
    }

    fun sendMessage(chatId: String, text: String) {
        if (text.isBlank()) return
        chats = chats.map { if (it.id == chatId) it.copy(lastMessage = text, time = "только что", unread = 0) else it }
    }
}

private val Bg = Color(0xFFF7F8FC)
private val Accent = Color(0xFF5B5FEF)

@Composable
fun ZunoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Accent,
            background = Bg,
            surface = Color.White
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZunoTheme { ZunoApp() } }
    }
}

@Composable
fun ZunoApp(vm: ZunoViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var selectedChat by remember { mutableStateOf<Chat?>(null) }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Лента") })
                NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Mail, null) }, label = { Text("Сообщения") })
                NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Профиль") })
            }
        }
    ) { padding ->
        if (selectedChat != null) {
            ChatScreen(vm, selectedChat!!, { selectedChat = null })
        } else {
            Box(Modifier.padding(padding)) {
                when (tab) {
                    0 -> FeedScreen(vm)
                    1 -> ChatsScreen(vm) { selectedChat = it }
                    2 -> ProfileScreen(vm)
                }
            }
        }
    }
}

@Composable
fun Header(title: String, action: @Composable (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        action?.invoke()
    }
}

@Composable
fun Avatar(user: User, size: Int = 48) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(Accent),
        contentAlignment = Alignment.Center
    ) { Text(user.initials, color = Color.White, fontWeight = FontWeight.Bold) }
}

@Composable
fun FeedScreen(vm: ZunoViewModel) {
    var showComposer by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }

    Column {
        Header("Zuno", {
            IconButton({}) { Icon(Icons.Default.NotificationsNone, "Уведомления") }
        })
        OutlinedTextField(
            value = search, onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Поиск пользователей") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(18.dp)
        )
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(vm.posts.filter { search.isBlank() || it.author.name.contains(search, true) }) { PostCard(it) }
        }
    }
    FloatingActionButton(
        onClick = { showComposer = true },
        modifier = Modifier.padding(18.dp)
    ) { Icon(Icons.Default.Add, "Новая публикация") }

    if (showComposer) {
        ComposerDialog({ showComposer = false }) { text ->
            vm.addPost(text); showComposer = false
        }
    }
}

@Composable
fun PostCard(post: Post) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(post.author, 44)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(post.author.name, fontWeight = FontWeight.Bold)
                    Text(post.time, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(post.text, style = MaterialTheme.typography.bodyLarge)
            if (post.hasPhoto) {
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFE9EBF8)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Image, null, tint = Accent, modifier = Modifier.size(48.dp))
                }
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({}) { Icon(Icons.Default.FavoriteBorder, "Лайк") }
                Text(post.likes.toString())
                IconButton({}) { Icon(Icons.Default.ChatBubbleOutline, "Комментарии") }
                Text(post.comments.toString())
                Spacer(Modifier.weight(1f))
                IconButton({}) { Icon(Icons.Default.Share, "Поделиться") }
            }
        }
    }
}

@Composable
fun ComposerDialog(onDismiss: () -> Unit, onPost: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая публикация") },
        text = {
            OutlinedTextField(text, { text = it }, placeholder = { Text("Что нового?") }, minLines = 4)
        },
        confirmButton = { TextButton({ onPost(text) }) { Text("Опубликовать") } },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun ChatsScreen(vm: ZunoViewModel, onOpen: (Chat) -> Unit) {
    Column {
        Header("Сообщения", { IconButton({}) { Icon(Icons.Default.Edit, "Новый чат") } })
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.chats) { chat ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(chat) }, shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(chat.user)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(chat.user.name, fontWeight = FontWeight.Bold)
                            Text(chat.lastMessage, color = Color.Gray, maxLines = 1)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(chat.time, style = MaterialTheme.typography.labelSmall)
                            if (chat.unread > 0) {
                                Badge { Text(chat.unread.toString()) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatScreen(vm: ZunoViewModel, chat: Chat, onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Назад") }
            Avatar(chat.user, 40)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(chat.user.name, fontWeight = FontWeight.Bold)
                Text(chat.user.status, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("Диалог с ${chat.user.name}", color = Color.Gray)
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, modifier = Modifier.weight(1f), placeholder = { Text("Сообщение...") }, singleLine = true)
            IconButton({
                vm.sendMessage(chat.id, text); text = ""
            }) { Icon(Icons.Default.Send, "Отправить") }
        }
    }
}

@Composable
fun ProfileScreen(vm: ZunoViewModel) {
    Column {
        Header("Профиль", { IconButton({}) { Icon(Icons.Default.Settings, "Настройки") } })
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(vm.me, 104)
            Spacer(Modifier.height(14.dp))
            Text(vm.me.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(vm.me.status, color = Accent)
            Spacer(Modifier.height(18.dp))
            OutlinedButton({}) { Text("Редактировать профиль") }
            Spacer(Modifier.height(20.dp))
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("О себе", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(vm.me.about, color = Color.Gray)
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton({}) { Icon(Icons.Default.PhotoCamera, null); Spacer(Modifier.width(8.dp)); Text("Изменить главное фото") }
        }
    }
}
